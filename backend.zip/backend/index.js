const express = require('express')
const mongoose=require('mongoose')
const dotEnv = require('dotenv')
const vendorRoutes = require('./routes/vendorRoutes')
const bodyParser = require('body-parser')
const firmRoutes = require('./routes/firmRoutes')
const productRoutes = require('./routes/productRoutes');
const path = require('path')

const app =express();
const PORT = 5000;

dotEnv.config()

mongoose.connect(process.env.MONGO_URI)
.then(()=>console.log("MongoDB connected successfullly"))
.catch((error)=>console.log(error))

app.use(bodyParser.json());
app.use('/vendor',vendorRoutes);
app.use('/firm',firmRoutes)
app.use('/product',productRoutes);
app.use('/uploads',express.static('uploads'));

app.listen(PORT,()=>{
    console.log(`The server is started and running successfully at ${PORT}`)
})
app.use('/home',(req,res)=>{
    res.send("<h1>Welcome to the POOJA FOODS</h1>")
})